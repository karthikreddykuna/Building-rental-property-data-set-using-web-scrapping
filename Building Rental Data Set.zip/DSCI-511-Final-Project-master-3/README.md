# Building rental property dataset using web scraping 

## Objective:

The objective of the project is to extract the rental properties data of a particular location.

Apartment hunting is tough, especially when you live in a city where there are a lot to options from where we want to figure out a way to make this burdensome task a bit easier.

## Methodology:

We have chosen https://www.apartments.com as it is one the leading online apartment website, offering renters access to information on more than 1,000,000 available units for rent.

## Terms and Conditions:

Before we scrap a website, we need to check the legal terms to confirm that web scraping can be performed on site or not. So, based on this we found that we can perform web scrapping on apartments.com site when we do it for personal or non-commercial purpose.

In addition to leagal terms, by looking at robots.txt of apartments.com we can scrap all the sections on the site except for the ones with apartments.com/services/ in the URL.

## Tools and Softwares:
1. Python3.0 or above
2. Beautifulsoup
3. Juypter Lab
4. Pandas
5. Regular Expresssion (RegEx) Library


## Design of Data Set:

1. Building the list of cities and their state from main page. This list will be further used to valid the user input (city and state).
2. User provides the desired city and state. Format of input should be "/philadelphia-pa/"
3. Identify the last page number.
4. Extract the URL of each property from all pages until last page. These URLs are stored in a list.
5. Invoke each URL and extract the fields mentioned below and form a dictionary.
6. Convert the dictionary into CSV using Pandas.



## Fields in data set

1. property name
2. property street
3. property city
4. property state
5. property zipcode
6. Studio (Price)
7. 1 Bedroom (Price)
8. 2 Bedrooms (Price)
9. 3 Bedrooms (Price)
10. Latitude
11. Longitude
12. URL


## Field and type
1. property name - string
2. property street - string
3. property city - string
4. property state - string
5. property zipcode - integer
6. Studio - string
7. 1 Bedroom - string
8. 2 Bedrooms - string
9. 3 Bedrooms - string
10. Latitude - float
11. Longitude - float
12. URL - string


## How to access data
In the generated CSV, we have each property details and also provided URL as well. This URL can be used to check the property details in website.


## Challenges:

Below are few challenges faced during building the data set.

1. While extracting data the last page number of the city, we observed that few cities has different patterns of showing last page number. There wasn’t a common blueprint followed for the hovering of page numbers.

2. While extracting the URL of each property, we could see few properties have different banner style due to which the property URL is stored in different tags.

3. Few properties do not have street names so we have used property name as street name for such cases.
